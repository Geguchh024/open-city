# SPDX-License-Identifier: GPL-3.0-or-later
"""The modular architectural kit: every module is a node group with a fixed frame and shared sizes.

    parts       chamfered boxes and the part builder every module uses
    openings    windows, French doors, storefronts, doors, stoops, shutters, flower boxes,
                balconies, awnings
    roofs       gable, hip and mansard roofs, dormers, chimneys, rooftop equipment
    street      street lights, benches, bins, hydrants, signs, bus shelter, cafe sets...
    nature      trees, shrubs, hedges, flower beds, fences, a fountain
    vehicles    hatchback, sedan, city car, delivery van
"""

from ..gn import Group
from . import nature, openings, parts, roofs, street, vehicles

SCATTER = "OC Scatter"
PROP_MODULES = (street, nature, vehicles)


def build_all():
    """Build every architectural group. Returns {name: node group}."""
    parts.build_cbox()
    trees = {}
    trees.update(openings.build_all())
    trees.update(roofs.build_all())
    return trees


def build_scatter(order):
    """`OC Scatter`: instances the prop library on points.

    Each point carries `oc_prop` (index into `order`), `oc_rot` (turn about Z) and `oc_scale`;
    other point attributes such as `oc_tint` travel with the instance to the shaders.
    """
    props = {}
    for mod in PROP_MODULES:
        props.update(dict(mod.build_all()))
    G = Group(SCATTER, [("Geometry", "geometry")], [("Geometry", "geometry")])
    g = G.g
    lib = []
    for key in order:
        n = g.nodes.new("GeometryNodeGroup")
        n.node_tree = props[key]
        lib.append(n.outputs[0])
    pts = G.i("Geometry")
    inst = g.instance(pts, g.library(lib), pick=True, index=g.named("oc_prop", "INT"),
                      rotation=g.euler(0.0, 0.0, g.named("oc_rot")), scale=g.named("oc_scale", "FLOAT_VECTOR"))
    return G.finish(Geometry=inst)


def group_names():
    names = [parts.CBOX, SCATTER]
    names += [n for n, _f in openings.BASE + openings.ADDONS]
    names += [roofs.GABLE, roofs.HIP, roofs.MANSARD, roofs.DORMER, roofs.CHIMNEY, *roofs.ROOFTOP]
    for mod in PROP_MODULES:
        names += [name for _key, name, _fn in mod.PROPS]
    return names
