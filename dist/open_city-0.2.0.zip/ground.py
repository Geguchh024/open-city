# SPDX-License-Identifier: GPL-3.0-or-later
"""The street surface as plain mesh data: asphalt, kerbed block islands with rounded corners, lawns,
alleys, garden paths, park paths and plaza, lane markings, crossings, parking bays, manholes and the
diorama base. No bpy: `build(plan)` returns vertices, faces and a material name per face.
"""

import math
import random

from .layout import CORNER_RADIUS, CURB

Z_MARK = 0.006


class MeshData:
    def __init__(self):
        self.verts = []
        self.faces = []
        self.mats = []

    def poly(self, pts, z, mat, flip=False):
        """A flat polygon (counter-clockwise from above) at height z."""
        base = len(self.verts)
        self.verts += [(p[0], p[1], z) for p in pts]
        idx = list(range(base, base + len(pts)))
        self.faces.append(idx[::-1] if flip else idx)
        self.mats.append(mat)

    def quad3(self, a, b, c, d, mat):
        base = len(self.verts)
        self.verts += [a, b, c, d]
        self.faces.append([base, base + 1, base + 2, base + 3])
        self.mats.append(mat)

    def rect(self, x0, x1, y0, y1, z, mat):
        self.poly([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], z, mat)

    def oriented_rect(self, cx, cy, ang, length, width, z, mat):
        c, s = math.cos(ang), math.sin(ang)
        hl, hw = length / 2, width / 2
        pts = [(cx + c * x - s * y, cy + s * x + c * y) for x, y in ((-hl, -hw), (hl, -hw), (hl, hw), (-hl, hw))]
        self.poly(pts, z, mat)

    def walls(self, pts, z0, z1, mat):
        """Vertical faces along a closed outline (counter-clockwise), facing outwards."""
        n = len(pts)
        for i in range(n):
            a, b = pts[i], pts[(i + 1) % n]
            self.quad3((a[0], a[1], z0), (b[0], b[1], z0), (b[0], b[1], z1), (a[0], a[1], z1), mat)

    def ring(self, outer, inner, z, mat):
        """The flat band between two outlines with the same number of points."""
        n = len(outer)
        for i in range(n):
            j = (i + 1) % n
            self.poly([outer[i], outer[j], inner[j], inner[i]], z, mat)


def rounded_rect(x0, x1, y0, y1, r, segs=5):
    """Corner points of a rectangle with rounded corners, counter-clockwise."""
    r = max(0.0, min(r, (x1 - x0) / 2 - 0.01, (y1 - y0) / 2 - 0.01))
    pts = []
    for cx, cy, a0 in ((x1 - r, y0 + r, -math.pi / 2), (x1 - r, y1 - r, 0.0), (x0 + r, y1 - r, math.pi / 2),
                       (x0 + r, y0 + r, math.pi)):
        for k in range(segs + 1):
            a = a0 + (math.pi / 2) * k / segs
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return pts


def build(plan):
    s = plan.settings
    m = MeshData()
    rng = random.Random(int(s["Seed"]) * 31 + 5)
    sw = s["Sidewalk Width"]
    X0, X1, Y0, Y1 = plan.extent

    # the road network and the edge of town
    m.rect(X0, X1, Y0, Y1, 0.0, "OC Asphalt")
    verge = sw + 5.0
    outer = (X0 - verge, X1 + verge, Y0 - verge, Y1 + verge)
    kerb_out = [(X0, Y0), (X0, Y1), (X1, Y1), (X1, Y0)]            # clockwise: the walls face the road
    m.walls(kerb_out, 0.0, CURB, "OC Curb")
    walk = (X0 - sw, X1 + sw, Y0 - sw, Y1 + sw)
    # outer sidewalk ring and grass verge, each as four strips
    _frame(m, (X0, X1, Y0, Y1), walk, CURB, "OC Sidewalk")
    _frame(m, walk, outer, CURB, "OC Grass")
    if s["Diorama Base"]:
        ox0, ox1, oy0, oy1 = outer
        m.walls([(ox0, oy0), (ox1, oy0), (ox1, oy1), (ox0, oy1)], -2.4, CURB, "OC Base")
        m.poly([(ox0, oy0), (ox1, oy0), (ox1, oy1), (ox0, oy1)], -2.4, "OC Base", flip=True)
    else:
        big = max(X1 - X0, Y1 - Y0) * 2.5
        _frame(m, outer, (outer[0] - big, outer[1] + big, outer[2] - big, outer[3] + big), CURB, "OC Grass")

    for b in plan.blocks:
        _island(m, b, plan)
    _markings(m, plan, rng)
    return m


def _frame(m, inner, outer, z, mat):
    """Four flat strips between an inner and an outer rectangle."""
    ix0, ix1, iy0, iy1 = inner
    ox0, ox1, oy0, oy1 = outer
    m.rect(ox0, ox1, oy0, iy0, z, mat)
    m.rect(ox0, ox1, iy1, oy1, z, mat)
    m.rect(ox0, ix0, iy0, iy1, z, mat)
    m.rect(ix1, ox1, iy0, iy1, z, mat)


def _island(m, b, plan):
    s = plan.settings
    sw = s["Sidewalk Width"]
    outer = rounded_rect(b.x0, b.x1, b.y0, b.y1, CORNER_RADIUS)
    inner = rounded_rect(b.x0 + 0.28, b.x1 - 0.28, b.y0 + 0.28, b.y1 - 0.28, CORNER_RADIUS - 0.28)
    m.walls(outer, 0.0, CURB, "OC Curb")
    m.ring(outer, inner, CURB, "OC Curb")
    m.poly(inner, CURB, "OC Sidewalk")
    ix0, ix1, iy0, iy1 = b.inner(sw)
    zl = CURB + 0.012
    if b.kind == "park":
        _park(m, b, plan, zl)
        return
    m.rect(ix0, ix1, iy0, iy1, zl, "OC Grass")
    zp = CURB + 0.02
    for key, a0, a1, kind in b.gaps:
        if kind != "alley":
            continue
        e = b.edges[key]
        pts = [e.at(a0, 0.0), e.at(a1, 0.0), e.at(a1, 12.0), e.at(a0, 12.0)]
        m.poly(_ccw(pts), zp, "OC Paving")
    for bd in b.buildings:
        if bd.setback < 1.0:
            continue
        e = bd.edge
        a, _stoop = bd.entrance()
        pts = [e.at(a - 0.6, 0.0), e.at(a + 0.6, 0.0), e.at(a + 0.6, bd.setback), e.at(a - 0.6, bd.setback)]
        m.poly(_ccw(pts), zp, "OC Paving")


def _park(m, b, plan, zl):
    s = plan.settings
    ix0, ix1, iy0, iy1 = b.inner(s["Sidewalk Width"])
    cx, cy = (ix0 + ix1) / 2, (iy0 + iy1) / 2
    plaza = getattr(b, "plaza", min(5.5, min(ix1 - ix0, iy1 - iy0) / 2 - 3.0))
    pw = getattr(b, "path_w", 2.4) / 2
    m.rect(ix0, ix1, iy0, iy1, zl, "OC Grass")
    zp = CURB + 0.02
    m.rect(ix0, ix1, cy - pw, cy + pw, zp, "OC Paving")
    m.rect(cx - pw, cx + pw, iy0, cy - pw, zp, "OC Paving")
    m.rect(cx - pw, cx + pw, cy + pw, iy1, zp, "OC Paving")
    circle = [(cx + (plaza + 2.0) * math.cos(a * math.tau / 32), cy + (plaza + 2.0) * math.sin(a * math.tau / 32))
              for a in range(32)]
    m.poly(circle, zp + 0.004, "OC Paving")


def _ccw(pts):
    area = sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1]
               for i in range(len(pts)))
    return pts if area > 0 else pts[::-1]


def _markings(m, plan, rng):
    s = plan.settings
    road = s["Street Width"]
    xs = sorted(st.centre for st in plan.streets if st.axis == "y")
    ys = sorted(st.centre for st in plan.streets if st.axis == "x")
    hw = road / 2
    z = Z_MARK
    for st in plan.streets:
        cross = xs if st.axis == "x" else ys
        # segments of this street between crossings
        for c0, c1 in zip(cross, cross[1:]):
            t0, t1 = c0 + hw, c1 - hw
            # crossings at both ends: zebra stripes across the carriageway
            for tc, sign in ((t0, 1.0), (t1, -1.0)):
                start = tc + sign * 0.7
                n = int((road - 0.8) / 1.0)
                for k in range(n):
                    off = -hw + 0.4 + 0.25 + k * 1.0 + ((road - 0.8) - n * 1.0) / 2
                    along = start + sign * 1.4
                    _mark(m, st, along, off, 2.8, 0.5, z, "OC Marking")
                # stop line on the approaching lane
                stop = tc + sign * 3.6
                # traffic keeps right: the approaching lane is on the driver's right
                lane = (sign if st.axis == "x" else -sign) * hw / 2
                _mark(m, st, stop, lane, 0.35, hw - 0.3, z, "OC Marking")
            # the centre line
            a = t0 + 5.0
            if st.main:
                length = (t1 - 5.0) - a
                if length > 0:
                    _mark(m, st, a + length / 2, -0.12, length, 0.12, z, "OC Marking Yellow")
                    _mark(m, st, a + length / 2, 0.12, length, 0.12, z, "OC Marking Yellow")
            else:
                while a + 2.0 < t1 - 5.0:
                    _mark(m, st, a + 1.0, 0.0, 2.0, 0.14, z, "OC Marking")
                    a += 4.5
            # a manhole or two
            for _ in range(rng.choice((0, 1, 1, 2))):
                t = rng.uniform(t0 + 6.0, t1 - 6.0) if t1 - t0 > 14 else None
                if t is None:
                    continue
                off = rng.uniform(-hw + 1.2, hw - 1.2)
                cx, cy = (t, st.centre + off) if st.axis == "x" else (st.centre + off, t)
                m.poly([(cx + 0.36 * math.cos(k * math.tau / 12), cy + 0.36 * math.sin(k * math.tau / 12))
                        for k in range(12)], z * 0.7, "OC Metal")
    # parking bays: a short tick at every bay boundary
    for (x, y, rot) in getattr(plan, "parking", []):
        m.oriented_rect(x, y, rot + math.pi / 2, 1.9, 0.1, z, "OC Marking")


def _mark(m, st, along, off, length, width, z, mat):
    """A painted rectangle `along` the street and `off` its centre line."""
    if st.axis == "x":
        m.oriented_rect(along, st.centre + off, 0.0, length, width, z, mat)
    else:
        m.oriented_rect(st.centre + off, along, math.pi / 2, length, width, z, mat)
