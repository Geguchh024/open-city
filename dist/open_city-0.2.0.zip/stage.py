# SPDX-License-Identifier: GPL-3.0-or-later
"""A warm, sunny stage for the town: a soft sun, a blue sky with gentle fill light, contact shadows and
the bright Standard colour transform, the look of the stylized references. Optional: `opencity.stage` applies it."""

import math

import bpy

from .styles import hexlin

SUN = "Open City Sun"


def _world(scene):
    world = scene.world
    if world is None or not world.name.startswith("Open City Sky"):
        world = bpy.data.worlds.new("Open City Sky")
        scene.world = world
    world.use_nodes = True
    nt = world.node_tree
    nt.nodes.clear()
    out = nt.nodes.new("ShaderNodeOutputWorld")
    # the camera sees a clear blue sky; the scene is lit by a softer, paler sky
    path = nt.nodes.new("ShaderNodeLightPath")
    coord = nt.nodes.new("ShaderNodeTexCoord")
    sep = nt.nodes.new("ShaderNodeSeparateXYZ")
    nt.links.new(coord.outputs["Generated"], sep.inputs[0])
    ramp = nt.nodes.new("ShaderNodeValToRGB")
    ramp.color_ramp.elements[0].position = 0.5
    ramp.color_ramp.elements[0].color = (*hexlin("#BFD9F2"), 1.0)
    ramp.color_ramp.elements[1].position = 0.85
    ramp.color_ramp.elements[1].color = (*hexlin("#5E9BE0"), 1.0)
    nt.links.new(sep.outputs["Z"], ramp.inputs[0])
    sky = nt.nodes.new("ShaderNodeBackground")
    nt.links.new(ramp.outputs[0], sky.inputs["Color"])
    sky.inputs["Strength"].default_value = 1.0
    fill = nt.nodes.new("ShaderNodeBackground")
    fill.inputs["Color"].default_value = (*hexlin("#D6E4F5"), 1.0)
    fill.inputs["Strength"].default_value = 0.55
    mix = nt.nodes.new("ShaderNodeMixShader")
    nt.links.new(path.outputs["Is Camera Ray"], mix.inputs[0])
    nt.links.new(fill.outputs[0], mix.inputs[1])
    nt.links.new(sky.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs["Surface"])
    return world


def _sun(scene, collection):
    ob = bpy.data.objects.get(SUN)
    if ob is None:
        ob = bpy.data.objects.new(SUN, bpy.data.lights.new(SUN, "SUN"))
        collection.objects.link(ob)
    sun = ob.data
    sun.energy = 4.2
    sun.color = hexlin("#FFF0D8")
    sun.angle = math.radians(2.5)
    for key, value in (("shadow_cascade_max_distance", 600.0), ("shadow_maximum_resolution", 0.01),
                       ("use_shadow_jitter", True)):
        if hasattr(sun, key):
            setattr(sun, key, value)
    # low and from the front left, so facades facing the street get light and long soft shadows
    ob.rotation_euler = (math.radians(52), 0.0, math.radians(-38))
    return ob


def setup(scene, collection=None):
    """Apply the stage to a scene. Returns the sun object."""
    _world(scene)
    sun = _sun(scene, collection or scene.collection)
    ee = scene.eevee
    for key, value in (("use_raytracing", True), ("use_fast_gi", True), ("fast_gi_distance", 6.0),
                       ("shadow_ray_count", 2), ("shadow_step_count", 10), ("taa_render_samples", 64),
                       ("use_shadows", True)):
        if hasattr(ee, key):
            setattr(ee, key, value)
    # Standard keeps the saturated, toy-like colours of the references (AgX greys them)
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.look = "None"
    scene.view_settings.exposure = -0.1
    return sun
