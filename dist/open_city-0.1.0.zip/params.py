# SPDX-License-Identifier: GPL-3.0-or-later
"""Every setting of the city generator, its presets, and a pure-Python reference of the layout maths.

No bpy in here: the node groups, the panels and the tests all read this table, and the tests use
`axis()` / `zone_of()` to check the node graphs against a plain-Python version of the same rules.
"""

import math

# -- zones -------------------------------------------------------------------------------------
PARK, RESIDENTIAL, MIDRISE, DOWNTOWN, INDUSTRIAL = range(5)
ZONE_NAMES = ("Park", "Residential", "Mid-rise", "Downtown", "Industrial")

# -- the settings --------------------------------------------------------------------------------
# (name, kind, default, options). `panel` groups them in the modifier and the sidebar.
LAYOUT, ZONING, BUILDINGS, ROADS, PROPS, LOOK, KITS = (
    "Layout", "Zoning", "Buildings", "Roads", "Props", "Look", "Custom Kits")

LAYOUT_MODES = ("Grid", "Organic", "Radial")

PARAMS = [
    ("Seed", "int", 0, dict(panel=LAYOUT, min=0, max=100000, tip="Changes every random choice in the city")),
    ("Lots X", "int", 48, dict(panel=LAYOUT, min=4, max=400, tip="City width in lots")),
    ("Lots Y", "int", 48, dict(panel=LAYOUT, min=4, max=400, tip="City depth in lots")),
    ("Lot Size", "float", 12.0, dict(panel=LAYOUT, min=3.0, max=40.0, subtype="DISTANCE",
                                    tip="Width of one lot, which is also the width of one road lane")),
    ("Block Size", "int", 5, dict(panel=LAYOUT, min=1, max=14, tip="Lots along one side of a city block")),
    ("Street Width", "int", 1, dict(panel=LAYOUT, min=1, max=4, tip="Width of normal streets in lots")),
    ("Avenue Every", "int", 3, dict(panel=LAYOUT, min=1, max=10, tip="A wide avenue after this many blocks")),
    ("Avenue Width", "int", 2, dict(panel=LAYOUT, min=1, max=5, tip="Width of avenues in lots")),
    ("Layout Mode", "int", 0, dict(panel=LAYOUT, min=0, max=2, tip="0 grid, 1 organic, 2 radial")),
    ("Warp Amount", "float", 14.0, dict(panel=LAYOUT, min=0.0, max=120.0, subtype="DISTANCE",
                                        tip="Organic layout: how far the streets wander")),
    ("Warp Scale", "float", 180.0, dict(panel=LAYOUT, min=20.0, max=800.0, subtype="DISTANCE",
                                        tip="Organic layout: size of the bends")),
    ("Radial Core", "float", 0.6, dict(panel=LAYOUT, min=0.1, max=2.0,
                                       tip="Radial layout: size of the empty middle (small is tight)")),

    ("Downtown Size", "float", 0.6, dict(panel=ZONING, min=0.05, max=1.5,
                                         tip="How far the dense centre reaches")),
    ("Density Noise", "float", 0.35, dict(panel=ZONING, min=0.0, max=1.0,
                                          tip="Breaks up the centre with random dense and sparse blocks")),
    ("Noise Scale", "float", 5.0, dict(panel=ZONING, min=1.0, max=30.0, tip="Size of those patches in blocks")),
    ("Park Amount", "float", 0.08, dict(panel=ZONING, min=0.0, max=0.6, tip="Share of blocks that become parks")),
    ("Industrial Amount", "float", 0.15, dict(panel=ZONING, min=0.0, max=0.6,
                                              tip="How much of the outskirts become industrial")),
    ("Height Scale", "float", 1.0, dict(panel=ZONING, min=0.2, max=3.0, tip="Multiplies every building height")),

    ("Floor Height", "float", 3.2, dict(panel=BUILDINGS, min=2.4, max=6.0, subtype="DISTANCE")),
    ("Lot Margin", "float", 1.2, dict(panel=BUILDINGS, min=0.0, max=4.0, subtype="DISTANCE",
                                      tip="Sidewalk and gap between a building and its lot edge")),
    ("Variation", "float", 0.6, dict(panel=BUILDINGS, min=0.0, max=1.0, tip="How different neighbouring buildings are")),
    ("Roof Detail", "bool", True, dict(panel=BUILDINGS, tip="Rooftop boxes, chimneys and antennas")),

    ("Curb Height", "float", 0.18, dict(panel=ROADS, min=0.0, max=0.6, subtype="DISTANCE")),
    ("Markings", "bool", True, dict(panel=ROADS, tip="Centre lines on streets and avenues")),
    ("Crosswalks", "bool", True, dict(panel=ROADS, tip="Zebra crossings at intersections")),

    ("Street Lights", "float", 0.5, dict(panel=PROPS, min=0.0, max=1.0)),
    ("Trees", "float", 0.5, dict(panel=PROPS, min=0.0, max=1.0)),
    ("Cars", "float", 0.35, dict(panel=PROPS, min=0.0, max=1.0)),
    ("Viewport Props", "bool", True, dict(panel=PROPS, tip="Switch off to keep the viewport fast; renders always show props")),

    ("Night", "float", 0.0, dict(panel=LOOK, min=0.0, max=1.0, tip="Lit windows and street lights")),

    ("Kit Residential", "collection", None, dict(panel=KITS, closed=True,
                                                 tip="Your own houses: a collection of models, each about 10 x 10 m, origin at the centre of the base, front facing -Y")),
    ("Kit Mid-rise", "collection", None, dict(panel=KITS, closed=True)),
    ("Kit Downtown", "collection", None, dict(panel=KITS, closed=True)),
    ("Kit Industrial", "collection", None, dict(panel=KITS, closed=True)),
]

BY_NAME = {p[0]: p for p in PARAMS}


def defaults():
    return {name: default for name, _kind, default, _o in PARAMS if default is not None}


def clamp_value(name, value):
    """Clamp a value to the range of the setting."""
    _n, kind, _d, opts = BY_NAME[name]
    if kind == "bool":
        return bool(value)
    if kind in ("int", "float"):
        lo, hi = opts.get("min"), opts.get("max")
        if lo is not None:
            value = max(lo, value)
        if hi is not None:
            value = min(hi, value)
        return int(round(value)) if kind == "int" else float(value)
    return value


# -- presets --------------------------------------------------------------------------------------
# Only the differences from the defaults.
PRESETS = {
    "Metropolis": dict(
        desc="Dense grid with a tall centre and wide avenues.",
        values={"Lots X": 64, "Lots Y": 64, "Downtown Size": 0.85, "Height Scale": 1.5,
                "Park Amount": 0.05, "Cars": 0.5, "Street Lights": 0.6}),
    "Mega City": dict(
        desc="Towers everywhere, tight blocks, a very tall core.",
        values={"Lots X": 80, "Lots Y": 80, "Block Size": 4, "Downtown Size": 1.25, "Height Scale": 2.4,
                "Density Noise": 0.2, "Park Amount": 0.02, "Industrial Amount": 0.05, "Lot Size": 10.0}),
    "Old Town": dict(
        desc="Small crooked blocks, low buildings and plenty of trees.",
        values={"Layout Mode": 1, "Lots X": 56, "Lots Y": 56, "Lot Size": 9.0, "Block Size": 3,
                "Avenue Every": 4, "Avenue Width": 1, "Warp Amount": 26.0, "Warp Scale": 120.0,
                "Downtown Size": 0.35, "Height Scale": 0.6, "Park Amount": 0.12, "Trees": 0.8,
                "Lot Margin": 0.8}),
    "Suburbia": dict(
        desc="Wide quiet blocks full of houses, parks and trees.",
        values={"Lots X": 60, "Lots Y": 60, "Block Size": 6, "Avenue Every": 2, "Downtown Size": 0.12,
                "Height Scale": 0.5, "Park Amount": 0.16, "Industrial Amount": 0.05, "Trees": 0.9,
                "Cars": 0.2, "Lot Margin": 1.8}),
    "Ring City": dict(
        desc="A radial city: dense core, ring roads and outer districts.",
        values={"Layout Mode": 2, "Lots X": 120, "Lots Y": 36, "Block Size": 4, "Avenue Every": 2,
                "Downtown Size": 0.45, "Radial Core": 0.5, "Height Scale": 1.3}),
    "Harbour District": dict(
        desc="Warehouses, factories and chimneys with a small centre.",
        values={"Industrial Amount": 0.6, "Downtown Size": 0.22, "Height Scale": 0.8, "Park Amount": 0.03,
                "Trees": 0.2, "Cars": 0.25, "Block Size": 6}),
    "Neon Night": dict(
        desc="The Metropolis with the lights on.",
        values={"Lots X": 64, "Lots Y": 64, "Downtown Size": 0.85, "Height Scale": 1.6, "Night": 1.0,
                "Cars": 0.55, "Street Lights": 0.9}),
}


def preset_values(name):
    """A full set of values for a preset: the defaults plus its changes."""
    v = defaults()
    v.update(PRESETS[name]["values"])
    return v


# -- the layout maths in plain Python ------------------------------------------------------------
def axis(i, block, street, every, ave_w):
    """One axis of the street grid: what the cell with index `i` is.

    Returns (kind, pos, band, run): kind 0 lot, 1 street, 2 avenue; pos the place of the cell inside
    its lot run or road band; band the width of that run or band; run the block number.
    The pattern repeats every `period` cells: an avenue, then `every` blocks with streets between.
    """
    period = ave_w + every * block + (every - 1) * street
    p = i % period
    stride = block + street
    if p < ave_w:
        return 2, p, ave_w, (i // period) * every
    q = p - ave_w
    qm = q % stride
    run = (i // period) * every + q // stride
    if qm >= block:
        return 1, qm - block, street, run
    return 0, qm, block, run


def cell_kind(ix, iy, params):
    """0 lot, 1 street, 2 avenue, 3 intersection for the cell (ix, iy)."""
    a = axis(ix, params["Block Size"], params["Street Width"], params["Avenue Every"], params["Avenue Width"])
    b = axis(iy, params["Block Size"], params["Street Width"], params["Avenue Every"], params["Avenue Width"])
    if a[0] and b[0]:
        return 3
    return a[0] or b[0]


def zone_of(density, is_park, is_industrial):
    """The zone a lot belongs to."""
    if is_park:
        return PARK
    if is_industrial:
        return INDUSTRIAL
    if density > 0.7:
        return DOWNTOWN
    if density > 0.4:
        return MIDRISE
    return RESIDENTIAL


def count_cells(params):
    """(lots, streets, avenues, intersections) cell counts of the layout, in plain Python."""
    out = [0, 0, 0, 0]
    for ix in range(params["Lots X"]):
        for iy in range(params["Lots Y"]):
            out[cell_kind(ix, iy, params)] += 1
    return tuple(out)


def organic_offset_limit(params):
    return params["Warp Amount"]


def radial_radius(params):
    """Inner radius of the radial layout in metres."""
    width = params["Lots X"] * params["Lot Size"]
    return width / (2.0 * math.pi) * params["Radial Core"]
