# SPDX-License-Identifier: GPL-3.0-or-later
"""Sidebar panels (3D View > City) and the Add menu entry."""

import bpy

from . import groups, inputs, params
from .ops import active_city
from .props import attr

# panels shown open by default in the sidebar
OPEN = (params.LAYOUT, params.ZONING)
# settings that only matter in some layout modes
ORGANIC_ONLY = ("Warp Amount", "Warp Scale")
RADIAL_ONLY = ("Radial Core",)


def _wrap(text, width):
    line, out = "", []
    for word in text.split():
        if len(line) + len(word) + 1 > width and line:
            out.append(line)
            line = word
        else:
            line = f"{line} {word}".strip()
    return out + ([line] if line else [])


class OPENCITY_PT_base:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "City"


class OPENCITY_PT_main(OPENCITY_PT_base, bpy.types.Panel):
    bl_label = "Open City"
    bl_idname = "OPENCITY_PT_main"

    def draw(self, context):
        layout = self.layout
        mod = active_city(context)
        if mod is None:
            col = layout.column()
            col.label(text="Generate a city in one click")
            for name, preset in params.PRESETS.items():
                row = col.row()
                row.scale_y = 1.3
                op = row.operator("opencity.add", text=name, icon="MOD_BUILD")
                op.preset = name
                for line in _wrap(preset["desc"], 44):
                    col.label(text=line)
                col.separator(factor=0.5)
            return

        obj = context.active_object
        if mod.node_group.get("oc_version", 0) < groups.VERSION:
            box = layout.box()
            box.alert = True
            box.label(text="This city was made by an older generator", icon="ERROR")
            box.operator("opencity.rebuild", icon="FILE_REFRESH")

        row = layout.row(align=True)
        row.menu("OPENCITY_MT_presets", text="Preset", icon="PRESET")
        row.operator("opencity.seed", text="", icon="FILE_REFRESH")
        sp = obj.open_city
        layout.prop(sp, "seed")
        s = inputs.settings_of(mod)
        width = s["Lots X"] * s["Lot Size"]
        depth = s["Lots Y"] * s["Lot Size"]
        layout.label(text=f"{width:.0f} x {depth:.0f} m, {s['Lots X'] * s['Lots Y']:,} lots")


class OPENCITY_MT_presets(bpy.types.Menu):
    bl_label = "City Presets"
    bl_idname = "OPENCITY_MT_presets"

    def draw(self, _context):
        for name, preset in params.PRESETS.items():
            op = self.layout.operator("opencity.preset", text=name)
            op.preset = name


def _draw_settings(layout, context, panel):
    obj = context.active_object
    sp = obj.open_city
    mod = active_city(context)
    mode = inputs.get(mod, "Layout Mode", 0)
    col = layout.column(align=True)
    for name, kind, _default, opts in params.PARAMS:
        if opts.get("panel") != panel or name == "Seed":
            continue
        if name in ORGANIC_ONLY and mode != 1:
            continue
        if name in RADIAL_ONLY and mode != 2:
            continue
        if name == "Layout Mode":
            col.row(align=True).prop(sp, attr(name), expand=True)
            col.separator()
        elif kind == "collection":
            col.prop(sp, attr(name))
        elif kind == "bool":
            col.prop(sp, attr(name), toggle=False)
        else:
            col.prop(sp, attr(name), slider=kind == "float" and opts.get("max", 2) <= 1.0)


def _make_panel(panel_name):
    idname = "OPENCITY_PT_" + attr(panel_name)

    class Panel(OPENCITY_PT_base, bpy.types.Panel):
        bl_label = panel_name
        bl_idname = idname
        bl_parent_id = "OPENCITY_PT_main"
        bl_options = set() if panel_name in OPEN else {"DEFAULT_CLOSED"}

        @classmethod
        def poll(cls, context):
            return active_city(context) is not None

        def draw(self, context):
            _draw_settings(self.layout, context, panel_name)

    Panel.__name__ = idname
    return Panel


class OPENCITY_PT_tools(OPENCITY_PT_base, bpy.types.Panel):
    bl_label = "Tools"
    bl_idname = "OPENCITY_PT_tools"
    bl_parent_id = "OPENCITY_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return active_city(context) is not None

    def draw(self, context):
        col = self.layout.column(align=True)
        col.operator("opencity.make_real", icon="MESH_DATA")
        col.operator("opencity.rebuild", icon="FILE_REFRESH")


PANELS = [_make_panel(p) for p in (params.LAYOUT, params.ZONING, params.BUILDINGS, params.ROADS,
                                    params.PROPS, params.LOOK, params.KITS)]
CLASSES = (OPENCITY_PT_main, OPENCITY_MT_presets, *PANELS, OPENCITY_PT_tools)


def _menu_add(self, _context):
    self.layout.operator("opencity.add", text="City", icon="MOD_BUILD").preset = "Metropolis"


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.VIEW3D_MT_mesh_add.append(_menu_add)


def unregister():
    bpy.types.VIEW3D_MT_mesh_add.remove(_menu_add)
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
