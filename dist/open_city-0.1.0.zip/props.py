# SPDX-License-Identifier: GPL-3.0-or-later
"""`object.open_city`: the generator's settings as ordinary Blender properties.

The modifier is the single source of truth. Each property reads and writes the matching modifier input
through getters and setters, so the sidebar, the modifier panel and animation never disagree and a saved
file keeps working without the add-on.
"""

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty

from . import inputs, params


def attr(name):
    """Property name for a setting: 'Lots X' -> 'lots_x'."""
    return name.lower().replace(" ", "_").replace("-", "_")


def _modifier(self):
    return inputs.city_modifier(self.id_data)


def _getter(name, default, cast):
    def get(self):
        mod = _modifier(self)
        if mod is None:
            return cast(default)
        return cast(inputs.get(mod, name, default))
    return get


def _setter(name):
    def set_(self, value):
        mod = _modifier(self)
        if mod is not None:
            inputs.set(mod, name, value)
    return set_


def _kit_update(name):
    def update(self, _context):
        mod = _modifier(self)
        if mod is not None:
            inputs.set(mod, name, getattr(self, attr(name)))
    return update


def _build():
    ann = {}
    for name, kind, default, opts in params.PARAMS:
        key = attr(name)
        tip = opts.get("tip", "")
        if kind == "collection":
            ann[key] = PointerProperty(type=bpy.types.Collection, name=name, description=tip,
                                       update=_kit_update(name))
        elif name == "Layout Mode":
            items = [(m.upper(), m, "") for m in params.LAYOUT_MODES]
            ann[key] = EnumProperty(
                name=name, description=tip, items=items,
                get=_getter(name, 0, int), set=_setter(name))
        elif kind == "bool":
            ann[key] = BoolProperty(name=name, description=tip, default=bool(default),
                                    get=_getter(name, default, bool), set=_setter(name))
        elif kind == "int":
            ann[key] = IntProperty(name=name, description=tip, default=int(default),
                                   min=opts.get("min", 0), max=opts.get("max", 1000),
                                   get=_getter(name, default, int), set=_setter(name))
        else:
            extra = {"unit": "LENGTH"} if opts.get("subtype") == "DISTANCE" else {}
            ann[key] = FloatProperty(name=name, description=tip, default=float(default),
                                     min=opts.get("min", 0.0), max=opts.get("max", 1.0),
                                     get=_getter(name, default, float), set=_setter(name), **extra)
    return type("OpenCityProps", (bpy.types.PropertyGroup,), {"__annotations__": ann})


OpenCityProps = _build()


def register():
    bpy.utils.register_class(OpenCityProps)
    bpy.types.Object.open_city = PointerProperty(type=OpenCityProps)


def unregister():
    del bpy.types.Object.open_city
    bpy.utils.unregister_class(OpenCityProps)
