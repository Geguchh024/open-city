# SPDX-License-Identifier: GPL-3.0-or-later
"""Reading and writing the generator's settings on a modifier.

Blender 5.2 keeps modifier inputs in `modifier.properties.inputs[identifier]["value"]`; older versions
used `modifier[identifier]`. Everything else goes through here and addresses settings by name.
"""

import bpy

from . import params

MODIFIER_NAME = "Open City"


def _ids(tree):
    return {it.name: it.identifier for it in tree.interface.items_tree
            if it.item_type == "SOCKET" and it.in_out == "INPUT"}


def _new_style(mod):
    props = getattr(mod, "properties", None)
    return props is not None and hasattr(props, "inputs")


def get(mod, name, default=None):
    ident = _ids(mod.node_group).get(name)
    if ident is None:
        return default
    try:
        if _new_style(mod):
            return mod.properties.inputs[ident]["value"]
        return mod[ident]
    except (KeyError, TypeError):
        return default


def set(mod, name, value):
    """Set one setting by name (clamped to its range). Returns False if the modifier has no such input."""
    ident = _ids(mod.node_group).get(name)
    if ident is None:
        return False
    if name in params.BY_NAME:
        value = params.clamp_value(name, value)
    if _new_style(mod):
        mod.properties.inputs[ident]["value"] = value
    else:
        mod[ident] = value
    mod.id_data.update_tag()
    return True


def read_all(mod):
    out = {}
    for name in _ids(mod.node_group):
        v = get(mod, name)
        if v is not None:
            out[name] = v
    return out


def apply(mod, values):
    for name, value in values.items():
        if value is not None:
            set(mod, name, value)


def city_modifier(obj):
    """The Open City modifier on an object, or None."""
    if obj is None:
        return None
    for mod in obj.modifiers:
        if mod.type == "NODES" and mod.node_group is not None and mod.node_group.name.startswith("OC City"):
            return mod
    return None


def settings_of(mod):
    """The values of every known setting, with the defaults filled in."""
    values = params.defaults()
    values.update({k: v for k, v in read_all(mod).items() if k in params.BY_NAME})
    return values


def users():
    """(object, modifier) for every object with an Open City modifier."""
    return [(o, m) for o in bpy.data.objects if (m := city_modifier(o)) is not None]
