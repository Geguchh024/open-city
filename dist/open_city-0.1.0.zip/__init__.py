# SPDX-License-Identifier: GPL-3.0-or-later
"""Open City: a modular, real-time city generator built on Geometry Nodes."""


def register():
    # imported here so the bpy-free modules (params) load without Blender
    from . import ops, props, ui
    props.register()
    ops.register()
    ui.register()


def unregister():
    from . import ops, props, ui
    ui.unregister()
    ops.unregister()
    props.unregister()
