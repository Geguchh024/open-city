# SPDX-License-Identifier: GPL-3.0-or-later
"""The materials the generator assigns. All procedural: no image textures, nothing to pack.

Facades draw their windows from world position and normal, so any wall of any building gets windows
that line up with the floors. The generator stores three constants on the geometry for them:
`oc_floor` (floor height), `oc_base` (height of the first floor) and `oc_night` (0..1).
"""

import bpy

from .gn import GB

# name -> viewport colour, for the Solid shading mode
SOLID = {
    "OC Road": (0.07, 0.07, 0.08, 1), "OC Sidewalk": (0.45, 0.44, 0.42, 1), "OC Lawn": (0.22, 0.38, 0.14, 1),
    "OC Marking White": (0.9, 0.9, 0.85, 1), "OC Marking Yellow": (0.9, 0.65, 0.1, 1),
    "OC Roof": (0.3, 0.2, 0.16, 1), "OC Roof Flat": (0.2, 0.2, 0.21, 1), "OC Residential": (0.75, 0.6, 0.5, 1), "OC Midrise": (0.6, 0.58, 0.55, 1),
    "OC Tower": (0.35, 0.5, 0.6, 1), "OC Industrial": (0.5, 0.5, 0.48, 1), "OC Metal": (0.2, 0.2, 0.22, 1),
    "OC Lamp": (1.0, 0.85, 0.5, 1), "OC Trunk": (0.25, 0.15, 0.08, 1), "OC Leaves": (0.15, 0.4, 0.12, 1),
    "OC Car": (0.6, 0.1, 0.1, 1), "OC Car Glass": (0.05, 0.07, 0.1, 1),
}

# the four facade looks: window pitch (m), window width and height as a share of the cell,
# wall palette, glass colour, glass roughness, how many windows light up at full night
FACADES = {
    "OC Residential": dict(pitch=3.0, wu=0.42, wv=0.5, glass=(0.07, 0.09, 0.12), rough=0.1, lit=0.4, metal=0.0,
                           palette=[(0.78, 0.62, 0.5), (0.85, 0.8, 0.7), (0.62, 0.38, 0.3), (0.8, 0.72, 0.55),
                                    (0.7, 0.7, 0.68)]),
    "OC Midrise": dict(pitch=2.8, wu=0.62, wv=0.55, glass=(0.06, 0.09, 0.13), rough=0.08, lit=0.42, metal=0.0,
                       palette=[(0.55, 0.53, 0.5), (0.42, 0.28, 0.22), (0.7, 0.68, 0.62), (0.35, 0.37, 0.4),
                                (0.62, 0.55, 0.45)]),
    "OC Tower": dict(pitch=2.2, wu=0.82, wv=0.72, glass=(0.04, 0.1, 0.16), rough=0.04, lit=0.35, metal=0.7,
                     palette=[(0.2, 0.26, 0.3), (0.28, 0.33, 0.36), (0.16, 0.2, 0.26), (0.3, 0.3, 0.32),
                              (0.22, 0.3, 0.28)]),
    "OC Industrial": dict(pitch=5.0, wu=0.6, wv=0.2, glass=(0.08, 0.1, 0.12), rough=0.2, lit=0.2, metal=0.0,
                          palette=[(0.5, 0.5, 0.48), (0.58, 0.45, 0.35), (0.4, 0.42, 0.45), (0.65, 0.63, 0.58)]),
}


def _new(name):
    mat = bpy.data.materials.get(name)
    if mat is not None:
        bpy.data.materials.remove(mat)
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    mat.node_tree.nodes.clear()
    mat.diffuse_color = SOLID.get(name, (0.5, 0.5, 0.5, 1))
    return mat


def _principled(g, **kw):
    n = g.node("ShaderNodeBsdfPrincipled", kw)
    out = g.node("ShaderNodeOutputMaterial")
    g.links.new(n.outputs["BSDF"], out.inputs["Surface"])
    return n


def _attr(g, name, kind="GEOMETRY"):
    return g.out("ShaderNodeAttribute", output="Fac", attribute_name=name, attribute_type=kind)


def _ramp(g, fac, colors):
    n = g.node("ShaderNodeValToRGB", {"Fac": fac})
    n.color_ramp.interpolation = "CONSTANT"
    els = n.color_ramp.elements
    count = len(colors)
    while len(els) < count:
        els.new(0.5)
    for i, c in enumerate(colors):
        els[i].position = i / count
        els[i].color = (*c, 1.0)
    return n.outputs["Color"]


def _mix_color(g, fac, a, b):
    return g.out("ShaderNodeMix", {"Factor": fac, "A": a, "B": b}, output="Result", data_type="RGBA")


def _simple(name, color, rough=0.8, metal=0.0, noise=None):
    mat = _new(name)
    g = GB(mat.node_tree)
    col = color
    if noise:
        coords = g.out("ShaderNodeTexCoord", output="Object")
        n = g.out("ShaderNodeTexNoise", {"Vector": coords, "Scale": noise[0], "Detail": 6.0}, output="Fac")
        dark = tuple(c * noise[1] for c in color)
        col = _mix_color(g, n, (*dark, 1.0), (*color, 1.0))
    _principled(g, **{"Base Color": col if not isinstance(col, tuple) else (*col, 1.0),
                      "Roughness": rough, "Metallic": metal})
    return mat


def _facade(name, spec):
    mat = _new(name)
    g = GB(mat.node_tree)
    geo = g.node("ShaderNodeNewGeometry")
    pos, nrm = geo.outputs["Position"], geo.outputs["Normal"]
    nx, ny, _nz = g.split(nrm)
    tang = g.vmath("NORMALIZE", g.xyz(g.math("MULTIPLY", ny, -1.0), nx, 0.0))
    u = g.vmath("DOT_PRODUCT", pos, tang, output="Value")
    _px, _py, pz = g.split(pos)
    floor_h = g.max(_attr(g, "oc_floor"), 0.5)
    base = _attr(g, "oc_base")
    night = _attr(g, "oc_night")
    tint = _attr(g, "oc_tint")

    cu = g.div(u, spec["pitch"])
    cv = g.div(g.sub(pz, base), floor_h)
    fu, fv = g.fract(cu), g.fract(cv)
    a = (1.0 - spec["wu"]) / 2.0
    b = (1.0 - spec["wv"]) / 2.0
    win_u = g.mul(g.math("GREATER_THAN", fu, a), g.math("LESS_THAN", fu, 1.0 - a))
    win_v = g.mul(g.math("GREATER_THAN", fv, b), g.math("LESS_THAN", fv, 1.0 - b))
    # the ground floor and anything below the first floor line stay solid wall
    above = g.math("GREATER_THAN", cv, 0.0)
    win = g.mul(g.mul(win_u, win_v), above)

    ids = g.xyz(g.floor(cu), g.floor(cv), g.mul(tint, 97.0))
    white = g.out("ShaderNodeTexWhiteNoise", {"Vector": ids}, output="Value", noise_dimensions="3D")
    lit = g.mul(win, g.mul(g.math("LESS_THAN", white, g.mul(night, spec["lit"])), g.math("GREATER_THAN", night, 0.01)))

    wall = _ramp(g, tint, spec["palette"])
    glass = (*spec["glass"], 1.0)
    base_col = _mix_color(g, win, wall, glass)
    warm = _mix_color(g, g.mul(white, 3.0), (1.0, 0.72, 0.4, 1.0), (0.75, 0.85, 1.0, 1.0))
    _principled(g, **{
        "Base Color": base_col,
        "Roughness": g.lerp(0.85, spec["rough"], win),
        "Metallic": g.mul(win, spec["metal"]),
        "Emission Color": warm,
        "Emission Strength": g.mul(lit, 1.4),
    })
    return mat


def _roof(name, palette):
    mat = _new(name)
    g = GB(mat.node_tree)
    col = _ramp(g, _attr(g, "oc_tint"), palette)
    _principled(g, **{"Base Color": col, "Roughness": 0.9})
    return mat


def _lamp():
    mat = _new("OC Lamp")
    g = GB(mat.node_tree)
    night = _attr(g, "oc_night")
    _principled(g, **{"Base Color": (0.9, 0.85, 0.7, 1.0), "Roughness": 0.3,
                      "Emission Color": (1.0, 0.78, 0.45, 1.0), "Emission Strength": g.mul(night, 25.0)})
    return mat


def _leaves():
    mat = _new("OC Leaves")
    g = GB(mat.node_tree)
    tint = _attr(g, "oc_tint", "INSTANCER")
    col = _ramp(g, tint, [(0.1, 0.3, 0.07), (0.16, 0.38, 0.08), (0.28, 0.4, 0.1), (0.4, 0.3, 0.08), (0.08, 0.25, 0.1)])
    _principled(g, **{"Base Color": col, "Roughness": 0.75})
    return mat


def _car():
    mat = _new("OC Car")
    g = GB(mat.node_tree)
    tint = _attr(g, "oc_tint", "INSTANCER")
    col = _ramp(g, tint, [(0.55, 0.04, 0.04), (0.05, 0.1, 0.35), (0.7, 0.7, 0.7), (0.03, 0.03, 0.03),
                          (0.75, 0.55, 0.05), (0.08, 0.28, 0.12), (0.45, 0.45, 0.5)])
    _principled(g, **{"Base Color": col, "Roughness": 0.25, "Metallic": 0.5})
    return mat


BUILDERS = {
    "OC Road": lambda: _simple("OC Road", (0.055, 0.055, 0.06), 0.92, noise=(30.0, 0.55)),
    "OC Sidewalk": lambda: _simple("OC Sidewalk", (0.4, 0.39, 0.37), 0.9, noise=(12.0, 0.8)),
    "OC Lawn": lambda: _simple("OC Lawn", (0.16, 0.32, 0.09), 0.95, noise=(4.0, 0.6)),
    "OC Marking White": lambda: _simple("OC Marking White", (0.8, 0.8, 0.76), 0.6),
    "OC Marking Yellow": lambda: _simple("OC Marking Yellow", (0.85, 0.58, 0.06), 0.6),
    "OC Metal": lambda: _simple("OC Metal", (0.1, 0.1, 0.11), 0.4, 0.8),
    "OC Trunk": lambda: _simple("OC Trunk", (0.16, 0.09, 0.05), 0.9),
    "OC Car Glass": lambda: _simple("OC Car Glass", (0.02, 0.03, 0.04), 0.05, 0.2),
    # pitched house roofs in tile and slate, flat roofs in gravel and membrane
    "OC Roof": lambda: _roof("OC Roof", [(0.36, 0.17, 0.12), (0.2, 0.21, 0.24), (0.3, 0.22, 0.17),
                                         (0.16, 0.16, 0.17), (0.42, 0.24, 0.16)]),
    "OC Roof Flat": lambda: _roof("OC Roof Flat", [(0.13, 0.13, 0.14), (0.2, 0.2, 0.2), (0.1, 0.11, 0.12),
                                                   (0.26, 0.25, 0.23)]),
    "OC Lamp": _lamp,
    "OC Leaves": _leaves,
    "OC Car": _car,
}
for _name, _spec in FACADES.items():
    BUILDERS[_name] = (lambda n=_name, s=_spec: _facade(n, s))

NAMES = tuple(BUILDERS)


def get(name):
    """The material, built on first use."""
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = BUILDERS[name]()
    return mat


def ensure_all():
    for name in NAMES:
        get(name)


def rebuild_all():
    for name in NAMES:
        BUILDERS[name]()
