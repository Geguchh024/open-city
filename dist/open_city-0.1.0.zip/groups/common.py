# SPDX-License-Identifier: GPL-3.0-or-later
"""Helpers shared by the node group builders."""

import math

from .. import materials

TAU = math.tau


def mat(g, name):
    """A Material node output for one of the generator's materials."""
    n = g.node("GeometryNodeInputMaterial")
    n.material = materials.get(name)
    return n.outputs[0]


def call(g, tree, bundle=None, **explicit):
    """Instance a node group and wire every input it shares a name with `bundle` (a dict of sockets).

    `explicit` overrides by name (underscores stand for spaces).
    """
    n = g.nodes.new("GeometryNodeGroup")
    n.node_tree = tree
    for s in n.inputs:
        if bundle and s.name in bundle:
            g.links.new(bundle[s.name], s)
    for k, v in explicit.items():
        g.set(n, k.replace("_", " "), v)
    return n


def out(node, name):
    for s in node.outputs:
        if s.name == name:
            return s
    raise KeyError(name)


def pick(g, cond, if_true, if_false, kind="FLOAT"):
    """`if_true` where `cond` holds, else `if_false` (reads in the order a person says it)."""
    return g.select(cond, if_false, if_true, kind)


def wall_and_roof(g, geo, wall, roof):
    """Walls get one material and everything that faces up (flat or sloped roofs) the other."""
    geo = g.material(geo, mat(g, wall))
    _nx, _ny, nz = g.split(g.normal())
    return g.material(geo, mat(g, roof), selection=g.gt(nz, 0.2))


def zone_is(g, zone):
    return g.eq(g.named("oc_zone"), float(zone))


def hash_pick(g, seed, id=None):
    """A random 0..1 field per element."""
    return g.rand(0.0, 1.0, seed=seed, id=id)
