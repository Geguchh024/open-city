# SPDX-License-Identifier: GPL-3.0-or-later
"""The layout: which cell is a lot, a street, an avenue or an intersection, and what each lot is for.

The city is a grid of lot-sized cells. A street is a run of cells, so the whole layout reduces to one
function of the cell index along each axis (`OC Axis`), evaluated for x and y. Everything the other
modules need is stored on the faces as `oc_*` attributes:

    oc_kind     0 lot, 1 street, 2 avenue, 3 intersection
    oc_axis     roads: 0 runs along x, 1 runs along y
    oc_c        roads: distance in cells from the cell centre to the road's centre line
    oc_cw_pos / oc_cw_neg   roads: an intersection lies ahead / behind along the road
    oc_dash     roads: 0 or 1, alternating along the road
    oc_edge     lots: bit mask of the sides that face a road (+x 1, -x 2, +y 4, -y 8)
    oc_zone     lots: 0 park, 1 residential, 2 mid-rise, 3 downtown, 4 industrial
    oc_density  lots: 0..1, how built-up the area is
    oc_rand, oc_rand2   lots: random per lot;  oc_brand random per block;  oc_tint random per building
"""

from ..gn import Group
from .common import TAU, call, out, pick


def build_axis():
    G = Group("OC Axis", [
        ("Index", "float"), ("Block", "float"), ("Street", "float"), ("Every", "float"), ("Avenue", "float"),
    ], [("Kind", "float"), ("Pos", "float"), ("Band", "float"), ("Run", "float")])
    g, i = G.g, G.i
    block, street, every, ave = i("Block"), i("Street"), i("Every"), i("Avenue")
    idx = i("Index")
    # the pattern repeats: an avenue, then `every` blocks with a street between each
    period = g.add(g.add(ave, g.mul(every, block)), g.mul(g.sub(every, 1.0), street))
    p = g.mod(idx, period)
    stride = g.add(block, street)
    in_ave = g.lt(p, ave)
    q = g.sub(p, ave)
    qm = g.mod(q, stride)
    on_street = g.land(g.lnot(in_ave), g.ge(qm, block))
    kind = pick(g, in_ave, 2.0, pick(g, on_street, 1.0, 0.0))
    pos = pick(g, in_ave, p, pick(g, on_street, g.sub(qm, block), qm))
    band = pick(g, in_ave, ave, pick(g, on_street, street, block))
    run = g.add(g.mul(g.floor(g.div(idx, period)), every), g.floor(g.div(g.max(q, 0.0), stride)))
    return G.finish(Kind=kind, Pos=pos, Band=band, Run=run)


def build_warp():
    G = Group("OC Warp", [
        ("Position", "vector"), ("Layout Mode", "float"), ("Warp Amount", "float"), ("Warp Scale", "float"),
        ("Radial Core", "float"), ("Seed", "float"), ("Width", "float"), ("Height", "float"),
    ], [("Position", "vector")])
    g, i = G.g, G.i
    pos = i("Position")
    x, y, z = g.split(pos)
    # organic: smooth noise pushes the points sideways, so streets bend but never cross
    shift = g.xyz(g.mul(i("Seed"), 13.7), g.mul(i("Seed"), 5.3), 0.0)
    base = g.vadd(g.vscale(pos, g.div(1.0, i("Warp Scale"))), shift)
    nx = g.noise(base, 1.0, 3.0)
    ny = g.noise(g.vadd(base, (31.4, 17.9, 0.0)), 1.0, 3.0)
    amt = g.mul(i("Warp Amount"), 3.0)
    organic = g.xyz(g.add(x, g.mul(g.sub(nx, 0.5), amt)), g.add(y, g.mul(g.sub(ny, 0.5), amt)), z)
    # radial: x becomes the angle around the middle, y the distance from it
    theta = g.mul(g.div(x, i("Width")), TAU)
    r0 = g.mul(g.div(i("Width"), TAU), i("Radial Core"))
    r = g.add(r0, g.add(y, g.mul(i("Height"), 0.5)))
    radial = g.xyz(g.mul(r, g.cos(theta)), g.mul(r, g.sin(theta)), z)
    mode = i("Layout Mode")
    res = pick(g, g.gt(mode, 0.5), organic, pos, "VECTOR")
    res = pick(g, g.gt(mode, 1.5), radial, res, "VECTOR")
    return G.finish(Position=res)


def warp_point(g, warp, bundle, pos):
    """The warped position of a flat position field, using the shared parameter bundle."""
    return out(call(g, warp, bundle, Position=pos), "Position")


def warp_heading(g, warp, bundle, pos):
    """Angle in radians that the warp turns the +X direction at `pos` by (a finite difference)."""
    a = warp_point(g, warp, bundle, pos)
    b = warp_point(g, warp, bundle, g.vadd(pos, (1.0, 0.0, 0.0)))
    dx, dy, _dz = g.split(g.vsub(b, a))
    return g.atan2(dy, dx)


def build_layout(axis):
    names = [
        ("Seed", "float"), ("Lots X", "float"), ("Lots Y", "float"), ("Lot Size", "float"),
        ("Block Size", "float"), ("Street Width", "float"), ("Avenue Every", "float"), ("Avenue Width", "float"),
        ("Layout Mode", "float"), ("Downtown Size", "float"), ("Density Noise", "float"),
        ("Noise Scale", "float"), ("Park Amount", "float"), ("Industrial Amount", "float"),
    ]
    G = Group("OC Layout", names, [("Geometry", "geometry")])
    g, i = G.g, G.i
    lx, ly, size = i("Lots X"), i("Lots Y"), i("Lot Size")
    width, height = g.mul(lx, size), g.mul(ly, size)
    grid = g.out("GeometryNodeMeshGrid", {
        "Size X": width, "Size Y": height,
        "Vertices X": g.add(lx, 1.0), "Vertices Y": g.add(ly, 1.0)}, output="Mesh")

    # which cell is this? Face centres sit at (index + 0.5) lots from the corner
    px, py, _pz = g.split(g.position())
    ix = g.floor(g.div(g.add(px, g.mul(width, 0.5)), size))
    iy = g.floor(g.div(g.add(py, g.mul(height, 0.5)), size))

    def ax(idx):
        return call(g, axis, None, Index=idx, Block=i("Block Size"), Street=i("Street Width"),
                    Every=i("Avenue Every"), Avenue=i("Avenue Width"))

    cx, cy = ax(ix), ax(iy)
    cxp, cxm = ax(g.add(ix, 1.0)), ax(g.sub(ix, 1.0))
    cyp, cym = ax(g.add(iy, 1.0)), ax(g.sub(iy, 1.0))
    kx, ky = out(cx, "Kind"), out(cy, "Kind")
    road_x, road_y = g.gt(kx, 0.5), g.gt(ky, 0.5)
    crossing = g.land(road_x, road_y)
    kind = pick(g, crossing, 3.0, pick(g, road_x, kx, ky))

    # a cell that is in a road row (road in y) belongs to a street that runs along x
    runs_x = road_y
    axis_f = pick(g, runs_x, 0.0, 1.0)
    pos_in_band = pick(g, runs_x, out(cy, "Pos"), out(cx, "Pos"))
    band = pick(g, runs_x, out(cy, "Band"), out(cx, "Band"))
    # distance in cells from the cell centre to the middle of the road, along +x or +y
    centre = g.sub(g.mul(band, 0.5), g.add(pos_in_band, 0.5))
    ahead = pick(g, runs_x, g.gt(out(cxp, "Kind"), 0.5), g.gt(out(cyp, "Kind"), 0.5), "BOOLEAN")
    behind = pick(g, runs_x, g.gt(out(cxm, "Kind"), 0.5), g.gt(out(cym, "Kind"), 0.5), "BOOLEAN")
    dash = g.mod(pick(g, runs_x, ix, iy), 2.0)

    # the sides of a lot that face a road: +x, -x, +y, -y are bits 1, 2, 4, 8
    def bit(c, weight):
        return g.mul(g.tofloat(g.gt(out(c, "Kind"), 0.5)), weight)

    edge = g.add(g.add(bit(cxp, 1.0), bit(cxm, 2.0)), g.add(bit(cyp, 4.0), bit(cym, 8.0)))

    # --- zoning ---------------------------------------------------------------------------
    flat = g.div(g.vlen(g.xyz(px, py, 0.0)), g.mul(g.max(width, height), 0.5))
    radial = g.div(g.add(py, g.mul(height, 0.5)), height)  # radial layout: dense at the inner ring
    dist = pick(g, g.gt(i("Layout Mode"), 1.5), radial, flat)
    core = g.clamp01(g.mul(g.sub(1.0, g.div(dist, i("Downtown Size"))), 1.3))
    bx, by = out(cx, "Run"), out(cy, "Run")
    seed = i("Seed")
    sv = g.mul(seed, 7.77)
    bvec = g.xyz(g.add(bx, sv), g.add(by, sv), 0.0)
    scale = g.div(1.0, i("Noise Scale"))
    # Blender's noise hugs 0.5, so stretch it to use the whole 0..1 range before comparing
    patch = g.map_range(g.noise(g.vscale(bvec, scale), 1.0, 2.0), 0.3, 0.7, 0.0, 1.0)
    density = g.clamp01(g.add(core, g.mul(g.sub(patch, 0.5), g.mul(i("Density Noise"), 1.6))))
    block_id = g.add(g.mul(bx, 1024.0), by)
    r_block = g.rand(0.0, 1.0, seed=7, id=block_id)
    is_park = g.land(g.lt(r_block, i("Park Amount")), g.lt(density, 0.78))
    ind_noise = g.map_range(
        g.noise(g.vadd(g.vscale(bvec, g.mul(scale, 0.8)), (41.0, 7.0, 0.0)), 1.0, 2.0), 0.3, 0.7, 0.0, 1.0)
    is_ind = g.land(g.gt(ind_noise, g.sub(1.0, g.mul(i("Industrial Amount"), 1.2))), g.lt(density, 0.5))
    built = pick(g, g.gt(density, 0.7), 3.0, pick(g, g.gt(density, 0.4), 2.0, 1.0))
    zone = pick(g, is_park, 0.0, pick(g, is_ind, 4.0, built))
    r_lot = g.rand(0.0, 1.0, seed=3, id=g.index())
    r_lot2 = g.rand(0.0, 1.0, seed=9, id=g.index())
    r_tint = g.rand(0.0, 1.0, seed=5, id=block_id)

    geo = g.store_many(grid, [
        ("oc_kind", kind), ("oc_axis", axis_f), ("oc_c", centre),
        ("oc_cw_pos", g.tofloat(ahead)), ("oc_cw_neg", g.tofloat(behind)), ("oc_dash", dash),
        ("oc_edge", edge), ("oc_zone", zone), ("oc_density", density),
        ("oc_rand", r_lot), ("oc_rand2", r_lot2), ("oc_brand", r_block),
        ("oc_tint", g.lerp(r_tint, r_lot2, 0.6)),
    ])
    return G.finish(Geometry=geo)
