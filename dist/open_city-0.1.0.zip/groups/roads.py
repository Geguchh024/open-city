# SPDX-License-Identifier: GPL-3.0-or-later
"""Road surface, centre lines and crosswalks.

Markings are small quads instanced on the road cells and realised, so they warp with the rest of the
layout. A street cell knows its direction (`oc_axis`), where the middle of the road is (`oc_c`) and
whether an intersection lies ahead or behind (`oc_cw_pos`, `oc_cw_neg`).
"""

import math

from ..gn import Group
from .common import mat, pick

Z_MARK = 0.03  # markings float just above the asphalt


def _quad(g, w, h, material):
    q = g.out("GeometryNodeMeshGrid", {"Size X": w, "Size Y": h, "Vertices X": 2, "Vertices Y": 2}, output="Mesh")
    return g.material(q, mat(g, material))


def build_roads():
    G = Group("OC Roads", [
        ("Geometry", "geometry"), ("Lot Size", "float"), ("Markings", "float"), ("Crosswalks", "float"),
    ], [("Geometry", "geometry")])
    g, i = G.g, G.i
    roads = i("Geometry")
    size = i("Lot Size")
    surface = g.material(roads, mat(g, "OC Road"))

    kind, axis, c = g.named("oc_kind"), g.named("oc_axis"), g.named("oc_c")
    straight = g.any_of(g.eq(kind, 1.0), g.eq(kind, 2.0))
    runs_x = g.lt(axis, 0.5)
    across = pick(g, runs_x, g.xyz(0.0, 1.0, 0.0), g.xyz(1.0, 0.0, 0.0), "VECTOR")
    along = pick(g, runs_x, g.xyz(1.0, 0.0, 0.0), g.xyz(0.0, 1.0, 0.0), "VECTOR")
    spin = g.euler(0.0, 0.0, g.mul(axis, math.pi / 2))
    centre = g.vadd(g.position(), g.xyz(0.0, 0.0, Z_MARK))
    on_line = g.all_of(straight, g.gt(c, -0.01), g.lt(c, 0.51))
    line_pos = g.vadd(centre, g.vscale(across, g.mul(c, size)))
    marks_on = g.gt(i("Markings"), 0.5)

    pieces = [surface]

    # white dashes down the middle of streets
    dashes = g.all_of(marks_on, on_line, g.eq(kind, 1.0), g.lt(g.named("oc_dash"), 0.5))
    pts = g.mesh_to_points(roads, selection=dashes, position=line_pos)
    pieces.append(g.realize(g.instance(pts, _quad(g, 1.0, 0.16, "OC Marking White"), rotation=spin,
                                       scale=g.xyz(g.mul(size, 0.4), 1.0, 1.0))))

    # a double yellow line down the middle of avenues
    solid = g.all_of(marks_on, on_line, g.eq(kind, 2.0))
    for side in (-1.0, 1.0):
        pos = g.vadd(line_pos, g.vscale(across, side * 0.2))
        pts = g.mesh_to_points(roads, selection=solid, position=pos)
        pieces.append(g.realize(g.instance(pts, _quad(g, 1.0, 0.12, "OC Marking Yellow"), rotation=spin,
                                           scale=g.xyz(size, 1.0, 1.0))))

    # zebra crossings at the end of every street cell that meets an intersection
    zebra_on = g.land(g.gt(i("Crosswalks"), 0.5), straight)
    bar_len = g.min(g.mul(size, 0.4), 3.2)
    spacing = g.div(size, 5.2)
    for flag, sign in (("oc_cw_pos", 1.0), ("oc_cw_neg", -1.0)):
        pts = g.mesh_to_points(roads, selection=g.land(zebra_on, g.gt(g.named(flag), 0.5)),
                               position=g.vadd(centre, g.vscale(along, g.mul(sign, g.sub(g.mul(size, 0.5),
                                                                                         g.add(1.0, g.mul(bar_len, 0.5)))))))
        bars = []
        for k in range(5):
            bar = _quad(g, 1.0, 0.55, "OC Marking White")
            bar = g.transform(bar, translation=g.xyz(0.0, g.mul(spacing, float(k - 2)), 0.0),
                              scale=g.xyz(bar_len, 1.0, 1.0))
            bars.append(bar)
        pieces.append(g.realize(g.instance(pts, g.join(*bars), rotation=spin)))

    return G.finish(Geometry=g.join(*pieces))
