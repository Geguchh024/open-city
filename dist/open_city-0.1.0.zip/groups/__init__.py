# SPDX-License-Identifier: GPL-3.0-or-later
"""The node groups that make up the generator.

    OC Axis        one axis of the street grid
    OC Layout      the lot grid: streets, avenues, lots, zones
    OC Warp        bends the flat layout (organic, radial)
    OC Building *  one building module per zone
    OC Lots        sidewalks, lawns, buildings and custom kits
    OC Roads       asphalt, centre lines, crosswalks
    OC Props       street lights, trees, cars
    OC City        the master group with every setting
"""

import bpy

from .. import inputs, materials
from . import buildings, city, layout, props, roads

VERSION = 1
MASTER = "OC City"


def group_names():
    names = ["OC Axis", "OC Layout", "OC Warp", "OC Lots", "OC Roads", "OC Props", "OC Lamp", "OC Tree",
             "OC Car", MASTER]
    names += [m[1] for m in buildings.MODULES]
    return names


def _build():
    materials.ensure_all()
    axis = layout.build_axis()
    warp = layout.build_warp()
    lay = layout.build_layout(axis)
    modules = {m[1]: m[2]() for m in buildings.MODULES}
    lots = buildings.build_lots(modules)
    rds = roads.build_roads()
    prp = props.build_props(props.build_lamp(), props.build_tree(), props.build_car(), warp)
    master = city.build_city(modules, lay, lots, rds, prp, warp)
    master["oc_version"] = VERSION
    for name in group_names():
        tree = bpy.data.node_groups.get(name)
        if tree is not None:
            tree.use_fake_user = False
    return master


def ensure():
    """The master node group, built the first time it is needed."""
    tree = bpy.data.node_groups.get(MASTER)
    if tree is None or tree.get("oc_version") != VERSION:
        return rebuild()
    return tree


def rebuild():
    """Rebuild every node group in place and re-attach the modifiers that used the old master."""
    users = []
    for _ob, mod in inputs.users():
        users.append((mod, inputs.read_all(mod)))
        mod.node_group = None
    for name in group_names():
        old = bpy.data.node_groups.get(name)
        if old is not None:
            bpy.data.node_groups.remove(old)
    master = _build()
    for mod, saved in users:
        mod.node_group = master
        inputs.apply(mod, saved)
    return master
