# SPDX-License-Identifier: GPL-3.0-or-later
"""Building modules and the lots stage that puts them on the city.

A module is a node group with one fixed interface: it receives the flat faces of the lots in its zone
(already lifted onto the sidewalk) and returns finished buildings. `MODULES` is the registry, so a new
building type is one builder function and one line there; the lots stage does the rest, including
swapping in the user's own models when a custom kit collection is set for the zone.
"""

import math

from .. import params as P
from ..gn import Group
from .common import call, mat, out, pick, wall_and_roof
from .layout import warp_heading, warp_point

MODULE_INPUTS = [
    ("Geometry", "geometry"), ("Floor Height", "float"), ("Height Scale", "float"), ("Variation", "float"),
    ("Lot Size", "float"), ("Lot Margin", "float"), ("Roof Detail", "float"),
]


def _fields(g):
    return g.named("oc_rand"), g.named("oc_rand2"), g.named("oc_density")


def _max_footprint(g, i):
    """Largest footprint scale that still leaves the sidewalk margin."""
    return g.clamp(g.sub(1.0, g.div(g.mul(i("Lot Margin"), 2.0), i("Lot Size"))), 0.2, 1.0)


def _detail(g, i):
    return g.gt(i("Roof Detail"), 0.5)


def _setback(g, mesh, selection, scale):
    """Shrink the top faces in `selection` without tapering the walls below them.

    Scaling a top face alone would drag the walls in with it, so extrude by nothing first: the old
    ring stays put as a flat ledge and only the new ring shrinks. Returns the mesh and the new top.
    """
    mesh, top, _side = g.extrude(mesh, selection=selection, offset_scale=0.0)
    return g.scale_el(mesh, scale, selection=top), top


def build_residential():
    G = Group("OC Building Residential", MODULE_INPUTS, [("Geometry", "geometry")])
    g, i = G.g, G.i
    r1, r2, _d = _fields(g)
    var = i("Variation")
    # houses sit in the middle of the lot with a yard around them
    sc = g.mul(_max_footprint(g, i), g.lerp(0.7, g.lerp(0.52, 0.86, r1), var))
    geo = g.scale_el(i("Geometry"), sc)
    floors = g.add(1.0, g.floor(g.mul(r2, g.add(1.0, g.mul(var, 1.99)))))
    wall_h = g.mul(g.mul(floors, i("Floor Height")), g.max(g.mul(i("Height Scale"), 0.8), 0.6))
    mesh, top, _side = g.extrude(geo, offset_scale=wall_h)
    # a hipped roof: extrude the top and pull it in
    mesh, top2, _side2 = g.extrude(mesh, selection=top, offset_scale=g.add(1.3, g.mul(r1, 1.6)))
    mesh = g.scale_el(mesh, 0.16, selection=top2)
    return G.finish(Geometry=wall_and_roof(g, mesh, "OC Residential", "OC Roof"))


def build_midrise():
    G = Group("OC Building Mid-rise", MODULE_INPUTS, [("Geometry", "geometry")])
    g, i = G.g, G.i
    r1, r2, d = _fields(g)
    var = i("Variation")
    sc = g.mul(_max_footprint(g, i), g.lerp(0.97, g.lerp(0.78, 0.97, r1), var))
    geo = g.scale_el(i("Geometry"), sc)
    floors = g.clamp(g.floor(g.add(g.add(3.5, g.mul(g.mul(d, 9.0), i("Height Scale"))), g.mul(g.mul(r2, 5.0), var))),
                     3.0, 40.0)
    mesh, top, _side = g.extrude(geo, offset_scale=g.mul(floors, i("Floor Height")))
    # rooftop plant room on some of them
    box = g.land(top, g.land(_detail(g, i), g.gt(g.named("oc_rand"), 0.4)))
    mesh, room = _setback(g, mesh, box, 0.5)
    mesh, _t, _s = g.extrude(mesh, selection=room, offset_scale=g.mul(i("Floor Height"), 0.8))
    return G.finish(Geometry=wall_and_roof(g, mesh, "OC Midrise", "OC Roof Flat"))


def build_tower():
    G = Group("OC Building Tower", MODULE_INPUTS, [("Geometry", "geometry")])
    g, i = G.g, G.i
    r1, r2, d = _fields(g)
    var, fh = i("Variation"), i("Floor Height")
    geo = g.scale_el(i("Geometry"), g.mul(_max_footprint(g, i), g.lerp(0.99, 0.94, g.mul(r1, var))))
    floors = g.clamp(g.floor(g.add(g.add(7.0, g.mul(g.mul(d, 14.0), i("Height Scale"))),
                                   g.mul(g.mul(r2, 9.0), var))), 7.0, 80.0)
    # a two-storey podium, then the tower, stepped in once on taller ones
    mesh, podium, _s = g.extrude(geo, offset_scale=g.mul(fh, 2.0))
    mesh, shaft = _setback(g, mesh, podium, g.lerp(0.92, g.lerp(0.74, 0.95, r1), var))
    stepped = g.gt(r1, 0.35)
    first_h = g.mul(g.mul(floors, fh), pick(g, stepped, 0.6, 1.0))
    mesh, tier1, _s = g.extrude(mesh, selection=shaft, offset_scale=first_h)
    mesh, upper = _setback(g, mesh, g.land(tier1, stepped), 0.78)
    mesh, tier2, _s = g.extrude(mesh, selection=upper, offset_scale=g.mul(g.mul(floors, fh), 0.4))
    final_top = g.lor(g.land(tier1, g.lnot(stepped)), tier2)
    # antenna
    spire = g.land(final_top, g.land(_detail(g, i), g.gt(g.named("oc_rand2"), 0.6)))
    mesh, mast = _setback(g, mesh, spire, 0.07)
    mesh, _t, _s = g.extrude(mesh, selection=mast, offset_scale=g.add(4.0, g.mul(g.named("oc_rand"), 9.0)))
    return G.finish(Geometry=wall_and_roof(g, mesh, "OC Tower", "OC Roof Flat"))


def build_industrial():
    G = Group("OC Building Industrial", MODULE_INPUTS, [("Geometry", "geometry")])
    g, i = G.g, G.i
    r1, r2, _d = _fields(g)
    sc = g.mul(_max_footprint(g, i), g.lerp(0.97, g.lerp(0.8, 0.95, r1), i("Variation")))
    geo = g.scale_el(i("Geometry"), sc)
    hall_h = g.mul(g.mul(g.add(1.0, g.floor(g.mul(r2, 1.99))), i("Floor Height")), 1.7)
    mesh, top, _s = g.extrude(geo, offset_scale=hall_h)
    detail = g.land(top, _detail(g, i))
    # roof boxes, or a chimney on a few
    box = g.land(detail, g.land(g.gt(g.named("oc_rand"), 0.35), g.lt(g.named("oc_rand"), 0.75)))
    stack = g.land(detail, g.gt(g.named("oc_rand"), 0.75))
    mesh, plant = _setback(g, mesh, box, 0.35)
    mesh, _t, _s = g.extrude(mesh, selection=plant, offset_scale=g.mul(i("Floor Height"), 0.7))
    mesh, flue = _setback(g, mesh, stack, 0.1)
    mesh, _t, _s = g.extrude(mesh, selection=flue, offset_scale=g.add(10.0, g.mul(g.named("oc_rand2"), 8.0)))
    return G.finish(Geometry=wall_and_roof(g, mesh, "OC Industrial", "OC Roof Flat"))


# zone, group name, builder, kit input name (None: no custom kit for the zone)
MODULES = [
    (P.RESIDENTIAL, "OC Building Residential", build_residential, "Kit Residential"),
    (P.MIDRISE, "OC Building Mid-rise", build_midrise, "Kit Mid-rise"),
    (P.DOWNTOWN, "OC Building Tower", build_tower, "Kit Downtown"),
    (P.INDUSTRIAL, "OC Building Industrial", build_industrial, "Kit Industrial"),
]


def _bit(g, field, k):
    """Bit k of a float bit-mask field."""
    return g.gt(g.mod(g.floor(g.div(field, float(2 ** k))), 2.0), 0.5)


def kit_instances(g, bundle, warp, kit, part):
    """The user's models from collection `kit`, one per lot of `part`, turned to face the road."""
    info = g.node("GeometryNodeCollectionInfo", {"Collection": kit, "Separate Children": True,
                                                  "Reset Children": True})
    models = info.outputs["Instances"]
    count = g.out("GeometryNodeAttributeDomainSize", {"Geometry": models}, output="Instance Count",
                  component="INSTANCES")
    edge = g.named("oc_edge")
    quarter = g.mul(g.rand(0, 3, seed=31, id=g.index(), kind="INT"), math.pi / 2)
    angle = pick(g, _bit(g, edge, 0), 0.0,
                 pick(g, _bit(g, edge, 1), math.pi,
                      pick(g, _bit(g, edge, 2), math.pi / 2,
                           pick(g, _bit(g, edge, 3), 3 * math.pi / 2, quarter))))
    pts = g.mesh_to_points(part)
    heading = warp_heading(g, warp, bundle, g.position())
    pts = g.set_pos(pts, position=warp_point(g, warp, bundle, g.position()))
    size = g.div(g.sub(bundle["Lot Size"], g.mul(bundle["Lot Margin"], 2.0)), 10.0)
    pick_idx = g.out("FunctionNodeRandomValue", {"Min": 0, "Max": g.max(g.sub(count, 1.0), 0.0), "Seed": 17},
                     data_type="INT")
    inst = g.instance(pts, models, pick=True, index=pick_idx,
                      rotation=g.euler(0.0, 0.0, g.add(g.add(angle, math.pi / 2), heading)),
                      scale=g.xyz(size, size, size))
    return count, inst


def build_lots(modules):
    """The lots stage: sidewalk slabs, lawns, every zone's buildings and custom kits."""
    inputs = [(n, k) for n, k in MODULE_INPUTS if n != "Geometry"] + [
        ("Geometry", "geometry"), ("Curb Height", "float"), ("Layout Mode", "float"), ("Warp Amount", "float"),
        ("Warp Scale", "float"), ("Radial Core", "float"), ("Seed", "float"), ("Width", "float"),
        ("Height", "float"),
    ] + [(m[3], "collection") for m in MODULES]
    G = Group("OC Lots", inputs, [("Mesh", "geometry"), ("Kits", "geometry")])
    g, i = G.g, G.i
    bundle = {n: i(n) for n, _k in inputs}
    warp = _warp_tree()
    lots = i("Geometry")
    curb = i("Curb Height")

    slab, _t, _s = g.extrude(lots, offset_scale=curb, individual=False)
    slab = g.material(slab, mat(g, "OC Sidewalk"))
    parts = [slab]

    # lawns in parks and residential lots
    green, _rest = g.separate(lots, g.any_of(g.eq(g.named("oc_zone"), float(P.PARK)),
                                             g.eq(g.named("oc_zone"), float(P.RESIDENTIAL))))
    lawn_sc = g.clamp(g.sub(1.0, g.div(g.mul(i("Lot Margin"), 2.0), i("Lot Size"))), 0.2, 1.0)
    lawn = g.scale_el(green, lawn_sc)
    lawn = g.set_pos(lawn, offset=g.xyz(0.0, 0.0, g.add(curb, 0.02)))
    parts.append(g.material(lawn, mat(g, "OC Lawn")))

    kits = []
    for zone, name, _builder, kit_name in MODULES:
        part, _rest = g.separate(lots, g.eq(g.named("oc_zone"), float(zone)))
        part = g.set_pos(part, offset=g.xyz(0.0, 0.0, curb))
        node = call(g, modules[name], bundle, Geometry=part)
        procedural = out(node, "Geometry")
        count, inst = kit_instances(g, bundle, warp, i(kit_name), part)
        use_kit = g.gt(count, 0.5)
        mesh_part = g.out("GeometryNodeSwitch", {"Switch": use_kit, "False": procedural}, input_type="GEOMETRY")
        kit_part = g.out("GeometryNodeSwitch", {"Switch": use_kit, "True": inst}, input_type="GEOMETRY")
        parts.append(mesh_part)
        kits.append(kit_part)
    return G.finish(Mesh=g.join(*parts), Kits=g.join(*kits))


def _warp_tree():
    import bpy
    return bpy.data.node_groups["OC Warp"]
