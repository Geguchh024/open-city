# SPDX-License-Identifier: GPL-3.0-or-later
"""The master node group: settings in, finished city out."""

from .. import params as P
from ..gn import Group
from .common import call, out
from .layout import warp_point


def build_city(modules, layout, lots, roads, props, warp):
    inputs = []
    for name, kind, default, opts in P.PARAMS:
        o = dict(opts)
        if default is not None:
            o["default"] = default
        inputs.append((name, kind, o))
    G = Group("OC City", inputs, [("Geometry", "geometry")])
    g, i = G.g, G.i

    bundle = {name: i(name) for name, _k, _d, _o in P.PARAMS}
    bundle["Width"] = g.mul(i("Lots X"), i("Lot Size"))
    bundle["Height"] = g.mul(i("Lots Y"), i("Lot Size"))

    grid = out(call(g, layout, bundle), "Geometry")
    lot_faces, road_faces = g.separate(grid, g.lt(g.named("oc_kind"), 0.5))

    lots_node = call(g, lots, bundle, Geometry=lot_faces)
    roads_node = call(g, roads, bundle, Geometry=road_faces)

    # one place to bend the whole flat layout: grid, organic or radial
    mesh = g.join(out(lots_node, "Mesh"), out(roads_node, "Geometry"))
    mesh = g.store(mesh, "oc_floor", i("Floor Height"), domain="POINT")
    mesh = g.store(mesh, "oc_base", i("Curb Height"), domain="POINT")
    mesh = g.store(mesh, "oc_night", i("Night"), domain="POINT")
    mesh = g.set_pos(mesh, position=warp_point(g, warp, bundle, g.position()))

    # props, which are warped as points before they are instanced
    prop_node = call(g, props, bundle, Geometry=lot_faces, Roads=road_faces)
    viewport = g.out("GeometryNodeIsViewport")
    show = g.lor(i("Viewport Props"), g.lnot(viewport))
    prop_geo = g.out("GeometryNodeSwitch", {"Switch": show, "True": out(prop_node, "Geometry")},
                     input_type="GEOMETRY")

    result = g.join(mesh, out(lots_node, "Kits"), prop_geo)
    return G.finish(Geometry=result)
