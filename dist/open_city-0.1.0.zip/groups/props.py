# SPDX-License-Identifier: GPL-3.0-or-later
"""Street lights, trees and cars.

Props are placed as points from the layout attributes, moved through the same warp as the rest of the
city, then instanced, so thousands of them cost almost nothing and stay editable.
"""

import math

from ..gn import Group
from .common import call, mat
from .layout import warp_heading, warp_point

# the four sides of a lot: bit in oc_edge, direction towards the road, heading in radians
SIDES = [(0, (1.0, 0.0, 0.0), 0.0), (1, (-1.0, 0.0, 0.0), math.pi),
         (2, (0.0, 1.0, 0.0), math.pi / 2), (3, (0.0, -1.0, 0.0), 3 * math.pi / 2)]


def _bit(g, field, k):
    return g.gt(g.mod(g.floor(g.div(field, float(2 ** k))), 2.0), 0.5)


def build_lamp(night_in=None):
    G = Group("OC Lamp", [("Night", "float")], [("Geometry", "geometry")])
    g = G.g
    pole = g.out("GeometryNodeMeshCylinder", {"Vertices": 6, "Radius": 0.08, "Depth": 5.2}, output="Mesh")
    pole = g.transform(pole, translation=(0.0, 0.0, 2.6))
    arm = g.box((1.1, 0.09, 0.09), at=(0.5, 0.0, 5.15))
    metal = g.material(g.join(pole, arm), mat(g, "OC Metal"))
    head = g.box((0.6, 0.3, 0.12), at=(1.0, 0.0, 5.1))
    head = g.store(head, "oc_night", G.i("Night"), domain="POINT")
    head = g.material(head, mat(g, "OC Lamp"))
    return G.finish(Geometry=g.join(metal, head))


def build_tree():
    G = Group("OC Tree", [], [("Geometry", "geometry")])
    g = G.g
    trunk = g.out("GeometryNodeMeshCylinder", {"Vertices": 6, "Radius": 0.15, "Depth": 2.6}, output="Mesh")
    trunk = g.material(g.transform(trunk, translation=(0.0, 0.0, 1.3)), mat(g, "OC Trunk"))
    crown = g.out("GeometryNodeMeshIcoSphere", {"Radius": 1.5, "Subdivisions": 1}, output="Mesh")
    crown = g.transform(crown, translation=(0.0, 0.0, 3.7), scale=(1.0, 1.0, 1.25))
    crown = g.material(crown, mat(g, "OC Leaves"))
    return G.finish(Geometry=g.join(trunk, crown))


def build_car():
    G = Group("OC Car", [], [("Geometry", "geometry")])
    g = G.g
    body = g.material(g.box((4.4, 1.85, 0.75), at=(0.0, 0.0, 0.65)), mat(g, "OC Car"))
    cabin = g.material(g.box((2.3, 1.65, 0.62), at=(-0.25, 0.0, 1.33)), mat(g, "OC Car Glass"))
    return G.finish(Geometry=g.join(body, cabin))


def _place(g, warp, bundle, pts, rot_z, scale=None, extra=()):
    """Remember the warp's heading, warp the points, return (points) ready for instancing."""
    pts = g.store(pts, "oc_h", warp_heading(g, warp, bundle, g.position()), domain="POINT")
    return g.set_pos(pts, position=warp_point(g, warp, bundle, g.position()))


def build_props(lamp, tree, car, warp):
    G = Group("OC Props", [
        ("Geometry", "geometry"), ("Roads", "geometry"), ("Lot Size", "float"), ("Lot Margin", "float"),
        ("Curb Height", "float"), ("Street Lights", "float"), ("Trees", "float"), ("Cars", "float"),
        ("Night", "float"), ("Seed", "float"), ("Layout Mode", "float"), ("Warp Amount", "float"),
        ("Warp Scale", "float"), ("Radial Core", "float"), ("Width", "float"), ("Height", "float"),
    ], [("Geometry", "geometry")])
    g, i = G.g, G.i
    bundle = {s.name: s for s in G.gin.outputs}
    lots, roads = i("Geometry"), i("Roads")
    size, margin, curb = i("Lot Size"), i("Lot Margin"), i("Curb Height")
    edge = g.named("oc_edge")
    zone = g.named("oc_zone")
    sidewalk = g.sub(g.mul(size, 0.5), g.mul(margin, 0.5))  # from the lot centre to the middle of the sidewalk
    lift = g.xyz(0.0, 0.0, curb)
    lamp_geo = call(g, lamp, None, Night=i("Night")).outputs["Geometry"]
    tree_geo = call(g, tree).outputs["Geometry"]
    car_geo = call(g, car).outputs["Geometry"]
    seed = g.mul(i("Seed"), 3.0)
    pieces = []

    def r(s, lo=0.0, hi=1.0):
        return g.rand(lo, hi, seed=g.add(seed, float(s)), id=g.index())

    for k, vec, heading in SIDES:
        toward = g.vscale(g.xyz(*vec), sidewalk)
        # street lights stand at the kerb side of the sidewalk
        want = g.land(_bit(g, edge, k), g.lt(r(40 + k), g.mul(i("Street Lights"), 0.55)))
        pts = g.mesh_to_points(lots, selection=want, position=g.vadd(g.vadd(g.position(), toward), lift))
        pts = _place(g, warp, bundle, pts, heading)
        pieces.append(g.instance(pts, lamp_geo, rotation=g.euler(0.0, 0.0, g.add(g.named("oc_h"), heading))))

        # street trees, to one side of the lamps
        want = g.land(_bit(g, edge, k), g.lt(r(50 + k), g.mul(i("Trees"), 0.5)))
        side = g.vscale(g.xyz(*(vec[1], vec[0], 0.0)), g.mul(g.select(g.gt(r(60 + k), 0.5), -1.0, 1.0),
                                                              g.mul(size, 0.3)))
        pts = g.mesh_to_points(lots, selection=want,
                               position=g.vadd(g.vadd(g.vadd(g.position(), toward), side), lift))
        pts = g.store(pts, "oc_tint", g.rand(0.0, 1.0, seed=g.add(seed, 70.0 + k)), domain="POINT")
        pts = _place(g, warp, bundle, pts, 0.0)
        s = g.rand(0.8, 1.3, seed=g.add(seed, 80.0 + k))
        pieces.append(g.instance(pts, tree_geo, scale=g.xyz(s, s, s),
                                 rotation=g.euler(0.0, 0.0, g.rand(0.0, 6.28, seed=g.add(seed, 90.0 + k)))))

    # trees scattered in parks
    park, _rest = g.separate(lots, g.eq(zone, 0.0))
    dist = g.outs("GeometryNodeDistributePointsOnFaces",
                  {"Mesh": park, "Density": g.mul(i("Trees"), 0.055), "Seed": g.floor(seed)})
    pts = g.set_pos(dist["points"], offset=g.xyz(0.0, 0.0, g.add(curb, 0.02)))
    pts = g.store(pts, "oc_tint", g.rand(0.0, 1.0, seed=g.add(seed, 5.0)), domain="POINT")
    pts = _place(g, warp, bundle, pts, 0.0)
    s = g.rand(0.8, 1.4, seed=g.add(seed, 6.0))
    pieces.append(g.instance(pts, tree_geo, scale=g.xyz(s, s, s),
                             rotation=g.euler(0.0, 0.0, g.rand(0.0, 6.28, seed=g.add(seed, 7.0)))))

    # cars drive in one of two lanes of every street cell
    kind, axis = g.named("oc_kind"), g.named("oc_axis")
    straight = g.any_of(g.eq(kind, 1.0), g.eq(kind, 2.0))
    runs_x = g.lt(axis, 0.5)
    across = g.select(runs_x, g.xyz(1.0, 0.0, 0.0), g.xyz(0.0, 1.0, 0.0), "VECTOR")
    along = g.select(runs_x, g.xyz(0.0, 1.0, 0.0), g.xyz(1.0, 0.0, 0.0), "VECTOR")
    lane = g.select(g.gt(r(100), 0.5), -1.0, 1.0)
    offset = g.vadd(g.vscale(across, g.mul(lane, g.mul(size, 0.22))),
                    g.vscale(along, g.mul(r(101, -0.25, 0.25), size)))
    want = g.land(straight, g.lt(r(102), g.mul(i("Cars"), 0.6)))
    pts = g.mesh_to_points(roads, selection=want, position=g.vadd(g.vadd(g.position(), offset),
                                                                  g.xyz(0.0, 0.0, 0.02)))
    pts = g.store(pts, "oc_tint", g.rand(0.0, 1.0, seed=g.add(seed, 8.0)), domain="POINT")
    pts = _place(g, warp, bundle, pts, 0.0)
    flip = g.select(g.gt(lane, 0.0), 0.0, math.pi)
    pieces.append(g.instance(pts, car_geo, rotation=g.euler(
        0.0, 0.0, g.add(g.add(g.mul(axis, math.pi / 2), flip), g.named("oc_h")))))

    return G.finish(Geometry=g.join(*pieces))
