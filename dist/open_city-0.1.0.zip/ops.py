# SPDX-License-Identifier: GPL-3.0-or-later
"""Operators: add a city, presets, seeds, baking to a real mesh, rebuilding the generator."""

import random

import bpy
from bpy.props import EnumProperty, StringProperty

from . import groups, inputs, params


def _preset_items(_self, _context):
    return [(n, n, p["desc"]) for n, p in params.PRESETS.items()]


def active_city(context):
    return inputs.city_modifier(context.active_object)


class OPENCITY_OT_add(bpy.types.Operator):
    bl_idname = "opencity.add"
    bl_label = "Add City"
    bl_description = "Add a new generated city at the 3D cursor"
    bl_options = {"REGISTER", "UNDO"}

    preset: EnumProperty(name="Preset", items=_preset_items)

    def execute(self, context):
        tree = groups.ensure()
        mesh = bpy.data.meshes.new("City")
        obj = bpy.data.objects.new("City", mesh)
        context.collection.objects.link(obj)
        obj.location = context.scene.cursor.location
        mod = obj.modifiers.new(inputs.MODIFIER_NAME, "NODES")
        mod.node_group = tree
        values = params.preset_values(self.preset or "Metropolis")
        values["Seed"] = random.randint(0, 9999)
        inputs.apply(mod, values)
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        return {"FINISHED"}


class OPENCITY_OT_preset(bpy.types.Operator):
    bl_idname = "opencity.preset"
    bl_label = "Apply Preset"
    bl_description = "Replace the settings with a preset, keeping the seed and custom kits"
    bl_options = {"REGISTER", "UNDO"}

    preset: StringProperty()

    @classmethod
    def poll(cls, context):
        return active_city(context) is not None

    def execute(self, context):
        mod = active_city(context)
        values = params.preset_values(self.preset)
        for keep in ("Seed", "Kit Residential", "Kit Mid-rise", "Kit Downtown", "Kit Industrial"):
            values.pop(keep, None)
        inputs.apply(mod, values)
        return {"FINISHED"}


class OPENCITY_OT_seed(bpy.types.Operator):
    bl_idname = "opencity.seed"
    bl_label = "New Seed"
    bl_description = "Roll a new random city with the same settings"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return active_city(context) is not None

    def execute(self, context):
        mod = active_city(context)
        old = inputs.get(mod, "Seed", 0)
        new = random.randint(0, 9999)
        while new == old:
            new = random.randint(0, 9999)
        inputs.set(mod, "Seed", new)
        return {"FINISHED"}


class OPENCITY_OT_make_real(bpy.types.Operator):
    bl_idname = "opencity.make_real"
    bl_label = "Make Real"
    bl_description = ("Bake the city into an ordinary mesh object (instances realised, materials kept) "
                      "that you can edit, export or sculpt. The generator stays untouched")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return active_city(context) is not None

    def execute(self, context):
        src = context.active_object
        tree = _realize_group()
        tmp = src.copy()
        tmp.data = src.data.copy()
        context.collection.objects.link(tmp)
        mod = tmp.modifiers.new("Realize", "NODES")
        mod.node_group = tree
        # always bake the full detail, whatever the viewport switch says
        city = inputs.city_modifier(tmp)
        inputs.set(city, "Viewport Props", True)
        context.view_layer.update()
        dg = context.evaluated_depsgraph_get()
        mesh = bpy.data.meshes.new_from_object(tmp.evaluated_get(dg))
        bpy.data.objects.remove(tmp)
        mesh.name = f"{src.name} (real)"
        obj = bpy.data.objects.new(mesh.name, mesh)
        context.collection.objects.link(obj)
        obj.matrix_world = src.matrix_world
        src.hide_set(True)
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        # Geometry Nodes primitives leave an empty first material slot behind
        bpy.ops.object.material_slot_remove_unused()
        self.report({"INFO"}, f"Baked {len(mesh.polygons):,} faces")
        return {"FINISHED"}


def _realize_group():
    tree = bpy.data.node_groups.get("OC Realize")
    if tree is not None:
        return tree
    from .gn import Group
    G = Group("OC Realize", [("Geometry", "geometry")], [("Geometry", "geometry")])
    return G.finish(Geometry=G.g.realize(G.i("Geometry")))


class OPENCITY_OT_rebuild(bpy.types.Operator):
    bl_idname = "opencity.rebuild"
    bl_label = "Update Generator"
    bl_description = "Rebuild the generator's node groups and materials, keeping every city's settings"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        groups.rebuild()
        self.report({"INFO"}, "Generator rebuilt")
        return {"FINISHED"}


CLASSES = (OPENCITY_OT_add, OPENCITY_OT_preset, OPENCITY_OT_seed, OPENCITY_OT_make_real, OPENCITY_OT_rebuild)


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
